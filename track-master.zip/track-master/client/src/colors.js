// src/colors.js
export const colors = {
    investment: '#4bc0c0', // Investment color
    expenses: '#ff6384',  // Expenses color
    savings: '#ffcd56',   // Savings color
};
